console.log("Login: redirection!");
setTimeout(redirection, 3000);
function redirection() {
    window.location.href = "./panel.html";
}
