# Fake Google Admin Panel
A simple check password in HTML, CSS and JavaScript
# Recreate for Admin Services
Use **Google Fake Admin Panel** through **Admin Services** again, quickly and easily!
# Usage
To use this page, access the official page [here](https://enioaiello.github.io/google-fake-admin-panel/) or clone the project via Git or GitHub Desktop via the directory of your choice.
## Git
Use the following command via Git Bash or Windows Terminal
```
git clone https://github.com/enioaiello/google-fake-admin-panel.git
```
## Github Desktop
Click on the "Code" button the project page and click on "Open in GitHub Desktop", make sure it is installed on your computer. If it is not on your computer, download it [here](https://desktop.github.com).
# Login
Log in to the default account using the following account:
```
root
```
```
toor
```
Or register (available soon) for free with a temporary account.
# Credits
This page has no real credits, however the favicon and the image files belong to Google.
# Features
- Create a free temporary account to test the project `in a futur update`
- Login with a default account 
- Support button to contact me in case of bugs 
- Access to some features in beta using the debug console
# Acknowledgements
[MatisBevilacqua](https://github.com/MatisBevilacqua), for his help with some functions of the site
