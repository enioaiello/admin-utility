function initialize() {
    localStorage.setItem('versionAdminUtility', '1.0');
    window.location.href = "./admin/login.html";
}

initialize();